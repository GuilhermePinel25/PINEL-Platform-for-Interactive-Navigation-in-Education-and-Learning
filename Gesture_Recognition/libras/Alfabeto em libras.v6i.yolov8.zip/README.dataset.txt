# Alfabeto em libras > 2023-08-15 4:09pm
https://universe.roboflow.com/elainesilva/alfabeto-em-libras-qrvnw

Provided by a Roboflow user
License: CC BY 4.0

Alfabeto em libras com as letras que não apresentam movimento.